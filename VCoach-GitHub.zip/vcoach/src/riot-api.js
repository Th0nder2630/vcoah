// riot-api.js
// Polls Riot's official Local Game Client API (https://127.0.0.1:2999)
// This is the same API used by Blitz.gg, TipsGenius, Overwolf apps — 100% Valorant TOS compliant
// No memory reading, no injection, no third-party scraping.

const https = require('https');
const http = require('http');

const AGENT = new https.Agent({ rejectUnauthorized: false }); // Riot uses self-signed cert

function fetchGameData() {
  return new Promise((resolve, reject) => {
    const req = https.get({
      hostname: '127.0.0.1',
      port: 2999,
      path: '/liveclientdata/allgamedata',
      agent: AGENT,
      timeout: 1500
    }, (res) => {
      let data = '';
      res.on('data', d => data += d);
      res.on('end', () => {
        try { resolve(JSON.parse(data)); }
        catch (e) { reject(e); }
      });
    });
    req.on('error', reject);
    req.on('timeout', () => { req.destroy(); reject(new Error('timeout')); });
  });
}

function fetchEvents() {
  return new Promise((resolve, reject) => {
    const req = https.get({
      hostname: '127.0.0.1',
      port: 2999,
      path: '/liveclientdata/eventdata',
      agent: AGENT,
      timeout: 1500
    }, (res) => {
      let data = '';
      res.on('data', d => data += d);
      res.on('end', () => {
        try { resolve(JSON.parse(data)); }
        catch (e) { reject(e); }
      });
    });
    req.on('error', reject);
    req.on('timeout', () => { req.destroy(); reject(new Error('timeout')); });
  });
}

module.exports = { fetchGameData, fetchEvents };
