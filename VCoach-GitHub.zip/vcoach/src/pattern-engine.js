// pattern-engine.js
// Analyzes gameplay events and detects patterns to generate tips
// Uses ONLY Riot's official Local Client API (port 2999) - fully Valorant-TOS compliant

class PatternEngine {
  constructor() {
    this.rounds = [];         // Per-round snapshots
    this.events = [];         // Kill/death/assist events
    this.currentRound = null;
    this.lastGameTime = 0;
    this.playerName = null;
    this.tips = [];
    this.shownTips = new Set();
    this.enemyPatterns = {};
    this.abilityUsageLog = [];
  }

  ingestGameData(data) {
    if (!data || !data.activePlayer) return [];

    this.playerName = data.activePlayer.summonerName;
    const gameTime = data.gameData?.gameTime || 0;
    const roundNumber = Math.floor(gameTime / 100); // approximate

    // Process events
    const newEvents = (data.events?.Events || []).filter(e => e.EventTime > this.lastGameTime);
    newEvents.forEach(ev => this.processEvent(ev, data));
    if (newEvents.length > 0) this.lastGameTime = Math.max(...newEvents.map(e => e.EventTime));

    // Snapshot current state
    const snapshot = this.buildSnapshot(data, gameTime);
    this.currentRound = snapshot;

    // Run pattern analysis
    const newTips = this.analyze(snapshot, data);
    return newTips;
  }

  processEvent(event, data) {
    const player = this.playerName;
    switch (event.EventName) {
      case 'Kill':
        this.events.push({
          type: event.KillerName === player ? 'kill' : (event.VictimName === player ? 'death' : 'teamkill'),
          killer: event.KillerName,
          victim: event.VictimName,
          weapon: event.KillStreakLength,
          time: event.EventTime,
          round: this.currentRound?.round || 0,
          assists: event.Assistants || []
        });
        if (event.VictimName === player) {
          this.logDeath(event, data);
        }
        break;
      case 'RoundStarted':
        this.pushRoundSnapshot();
        break;
      case 'RoundEnded':
        this.pushRoundSnapshot();
        break;
    }
  }

  logDeath(event, data) {
    // Track death context for pattern analysis
    const abilities = data.activePlayer?.abilities;
    const credits = data.activePlayer?.championStats?.currentGold || 0;
    this.abilityUsageLog.push({
      time: event.EventTime,
      abilitiesUnused: this.countUnusedAbilities(abilities),
      credits,
      round: this.currentRound?.round || 0,
      killer: event.KillerName
    });
  }

  countUnusedAbilities(abilities) {
    if (!abilities) return 0;
    let unused = 0;
    ['ability1', 'ability2', 'grenade', 'ultimate'].forEach(a => {
      if (abilities[a] && abilities[a].charges > 0) unused++;
    });
    return unused;
  }

  buildSnapshot(data, gameTime) {
    const ap = data.activePlayer;
    const allPlayers = data.allPlayers || [];
    const allies = allPlayers.filter(p => p.team === ap.team);
    const enemies = allPlayers.filter(p => p.team !== ap.team);

    return {
      time: gameTime,
      round: Math.floor(gameTime / 100),
      health: ap.championStats?.currentHealth || 100,
      credits: ap.championStats?.currentGold || 0,
      abilities: ap.abilities,
      kills: ap.scores?.kills || 0,
      deaths: ap.scores?.deaths || 0,
      assists: ap.scores?.assists || 0,
      hs: ap.scores?.headShotsHit || 0,
      shots: ap.scores?.shotsFired || 0,
      alliesAlive: allies.filter(p => p.isAlive !== false).length,
      enemiesAlive: enemies.filter(p => p.isAlive !== false).length,
      enemyData: enemies.map(e => ({ name: e.summonerName, agent: e.championName, alive: e.isAlive })),
      item0: ap.items?.find(i => i.itemID && i.slot === 'weapon') || null,
    };
  }

  pushRoundSnapshot() {
    if (this.currentRound) {
      this.rounds.push({ ...this.currentRound });
      this.analyzeEnemyPatterns();
    }
  }

  analyzeEnemyPatterns() {
    // Track which enemies kill most, same killer repeatedly = rush pattern
    const recentDeaths = this.events.filter(e => e.type === 'death').slice(-6);
    const killerCounts = {};
    recentDeaths.forEach(e => {
      killerCounts[e.killer] = (killerCounts[e.killer] || 0) + 1;
    });
    this.enemyPatterns.frequentKillers = Object.entries(killerCounts)
      .sort((a, b) => b[1] - a[1])
      .map(([name, count]) => ({ name, count }));
  }

  analyze(snap, data) {
    const tips = [];
    const round = this.rounds.length;
    const key = (id) => `${id}-${round}`;

    // --- ECONOMY PATTERNS ---
    const credits = snap.credits;
    if (credits > 3900 && round > 2 && !this.shownTips.has(key('eco-fullbuy'))) {
      const previousBuy = this.rounds.slice(-3).filter(r => r.credits < 2000).length;
      if (previousBuy >= 2) {
        tips.push({ id: key('eco-fullbuy'), category: 'economy', priority: 'high',
          title: 'Save Round Pattern Detected',
          body: `You've been saving 2+ rounds. With ${credits} creds now, you can full-buy. Don't half-buy — wait for full armor + rifle.`,
          icon: '💰', color: '#ffd700' });
        this.shownTips.add(key('eco-fullbuy'));
      }
    }

    if (credits < 800 && round > 3 && snap.deaths >= 2 && !this.shownTips.has(key('broke'))) {
      tips.push({ id: key('broke'), category: 'economy', priority: 'medium',
        title: 'Eco Round — Play Safe',
        body: 'Under 800 creds. Play for picks only. Don\'t push — let them come to you. A traded kill funds next round.',
        icon: '💸', color: '#ffd700' });
      this.shownTips.add(key('broke'));
    }

    // --- ABILITY WASTE PATTERN ---
    const recentDeathsWithAbilities = this.abilityUsageLog.filter(d => d.round >= round - 2 && d.abilitiesUnused >= 2);
    if (recentDeathsWithAbilities.length >= 2 && !this.shownTips.has(key('ability-waste'))) {
      tips.push({ id: key('ability-waste'), category: 'utility', priority: 'high',
        title: 'Abilities Wasted on Death',
        body: `You died ${recentDeathsWithAbilities.length}x in a row with 2+ unused abilities. Use your util BEFORE taking fights — don't die with charges.`,
        icon: '🧪', color: '#00d4ff' });
      this.shownTips.add(key('ability-waste'));
    }

    // --- DEATH STREAK ---
    const recentDeaths = this.events.filter(e => e.type === 'death').slice(-3);
    if (recentDeaths.length === 3 && recentDeaths.every(d => d.round >= round - 2) && !this.shownTips.has(key('deathstreak'))) {
      tips.push({ id: key('deathstreak'), category: 'positioning', priority: 'urgent',
        title: '3 Deaths in a Row',
        body: 'You\'ve died 3 times quickly. Change your angle or position. Holding the same spot is giving free info. Play slower, peek less.',
        icon: '⚠️', color: '#ff4655' });
      this.shownTips.add(key('deathstreak'));
    }

    // --- SAME KILLER PATTERN ---
    const topKiller = this.enemyPatterns.frequentKillers?.[0];
    if (topKiller && topKiller.count >= 2 && !this.shownTips.has(key(`killer-${topKiller.name}`))) {
      tips.push({ id: key(`killer-${topKiller.name}`), category: 'enemy', priority: 'high',
        title: 'Enemy Pattern: Repeat Kills',
        body: `${topKiller.name} has eliminated you ${topKiller.count}x. They know your position. Change your rotation and don't re-peek the same angle.`,
        icon: '👁️', color: '#ff6b35' });
      this.shownTips.add(key(`killer-${topKiller.name}`));
    }

    // --- LOW HEALTH WARNING ---
    if (snap.health < 50 && snap.health > 0 && snap.enemiesAlive >= 3 && !this.shownTips.has(key('low-hp-many'))) {
      tips.push({ id: key('low-hp-many'), category: 'positioning', priority: 'urgent',
        title: 'Low HP — Avoid Fighting',
        body: `${snap.health} HP with ${snap.enemiesAlive} enemies alive. Retreat, heal if possible. Don't trade at low HP — you're worth more alive.`,
        icon: '❤️', color: '#ff4655' });
      this.shownTips.add(key('low-hp-many'));
    }

    // --- OUTNUMBERED ---
    if (snap.alliesAlive === 1 && snap.enemiesAlive >= 3 && !this.shownTips.has(key('outnumbered'))) {
      tips.push({ id: key('outnumbered'), category: 'positioning', priority: 'urgent',
        title: '1v3+ Situation',
        body: 'You\'re last alive vs 3+. Play for time — don\'t rush the spike. Force them to push, hold a narrow angle, one at a time.',
        icon: '🎯', color: '#ff4655' });
      this.shownTips.add(key('outnumbered'));
    }

    // --- HS RATE ---
    if (snap.shots > 30 && (snap.hs / Math.max(snap.shots, 1)) < 0.15 && round > 5 && !this.shownTips.has(key('hs-rate'))) {
      tips.push({ id: key('hs-rate'), category: 'aim', priority: 'low',
        title: 'Headshot Rate Low',
        body: `Under 15% headshot rate this game. Try to keep crosshair at head level before every corner. Spray control starts after bullet 3.`,
        icon: '🎯', color: '#a8ff3e' });
      this.shownTips.add(key('hs-rate'));
    }

    // --- CLUTCH PEEL ---
    if (snap.alliesAlive >= 3 && snap.enemiesAlive === 1 && !this.shownTips.has(key('trade-up'))) {
      tips.push({ id: key('trade-up'), category: 'strategy', priority: 'medium',
        title: '5v1 — Clean It Up',
        body: 'You have a numbers advantage. Don\'t rush — funnel from multiple angles. Call which site and execute together.',
        icon: '📡', color: '#00d4ff' });
      this.shownTips.add(key('trade-up'));
    }

    return tips;
  }

  getSessionSummary() {
    const totalDeaths = this.events.filter(e => e.type === 'death').length;
    const totalKills = this.events.filter(e => e.type === 'kill').length;
    const wastedAbilityDeaths = this.abilityUsageLog.filter(d => d.abilitiesUnused >= 2).length;
    const rounds = this.rounds.length;

    const patterns = [];

    if (wastedAbilityDeaths / Math.max(totalDeaths, 1) > 0.4) {
      patterns.push({ label: 'Ability waste', desc: 'Dying with unused abilities frequently', severity: 'high' });
    }
    const deathsPerRound = totalDeaths / Math.max(rounds, 1);
    if (deathsPerRound > 1.2) {
      patterns.push({ label: 'Over-peeking', desc: 'Too many deaths per round — playing too aggressive', severity: 'high' });
    }
    if (this.enemyPatterns.frequentKillers?.length > 0) {
      const top = this.enemyPatterns.frequentKillers[0];
      if (top.count >= 3) {
        patterns.push({ label: 'Re-peeking same angle', desc: `${top.name} killed you ${top.count}x — you keep peeking the same spot`, severity: 'high' });
      }
    }

    return { totalKills, totalDeaths, rounds, patterns };
  }
}

module.exports = PatternEngine;
